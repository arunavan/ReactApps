import React,{Component} from 'react'
import MovieService from './MovieService'
// eslint-disable-next-line
const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);
const validateForm = (errors) => {
  let valid = true;
  Object.values(errors).forEach(
    (val) => val.length > 0 && (valid = false)
  );
  return valid;
}
const countErrors = (errors) => {
  let count = 0;
  Object.values(errors).forEach(
    (val) => val.length > 0 && (count = count+1)
  );
  return count;
}
class Add extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOnline: false,
      formValid: false,
      errorCount: null,
      errors: {
        name: '',
        rating: '',
        genre: '',
       // category:''
      }
    };
  }
  handleChange = (event) => {
    event.preventDefault();
    const { name, value } = event.target;
    let errors = this.state.errors;
     switch (name) {
      case 'name': 
        errors.name = 
          value.length < 5
            ? 'Full Name must be 5 characters long!'
            : '';
        break;
      case 'rating': 
        errors.rating = 
          value<=0
            ? 'provide rating >0'
            : 'provide rating!';
        break;
      case 'genre': 
        errors.genre = 
          value.length < 8
            ? 'generation should be  8 characters long!'
            : '';
        break;
      default:
        break;
    }
    this.setState({errors, [name]: value});
  }
 componentDidAmount()
  {   //let movie = {name: this.state.name, rating: this.state.rating, genre: this.state.genre};
     
  //  MovieService.createMovie(this.state.errors);
   // MovieService.createMovie(movie);
            

  }
  handleSubmit = (event) => {
    event.preventDefault();
    console.log(this.state.name+"  "+this.state.rating+"  "+this.state.genre);
    this.setState({formValid: validateForm(this.state.errors)});
    this.setState({errorCount: countErrors(this.state.errors)});
    let movie = {name: this.state.name, rating: this.state.rating, genre: this.state.genre};
     
  //  MovieService.createMovie(this.state.errors);
    MovieService.createMovie(movie);
  }
  render() {
    const {errors} = this.state;
    console.log(this.state.name +  ' '+ this.state.rating  +'  '+this.state.genre);
     return (
       <div className='wrapper'>
        <div className='form-wrapper'>
            {this.state.errors.name}
            {this.state.errors.rating}
            {this.state.errors.genre}
          <h2>Create Account</h2>
          <form onSubmit={this.handleSubmit} noValidate>
            <div className='name'>
              <label htmlFor="name">Name </label>
              <input type='text' name='name' onChange={this.handleChange} noValidate />
              {errors.name.length > 0 && 
                <span className='error'>{errors.name}</span>}
            </div>
            <div className='rating'>
              <label htmlFor="rating">Give Rating</label>
              <input type='rating' name='rating' onChange={this.handleChange} noValidate />
              {errors.rating.length > 0 && 
                <span className='error'>{errors.rating}</span>}
            </div>
            
            <label>
         
          <br></br>
          Movie Generation:
          <select name="genre" value={this.state.genre} onChange={this.handleChange}>
            <option value="Drama">Drama</option>
            <option value="Fiction">Fiction</option>
            <option value="Sattire">Sattire</option>
           
          </select>
        </label>
        <br></br>
       

            <div className='submit'>
              <button>Add Movie</button>
            </div>
            </form>
        </div>
      </div>
    );
  }
}


export default Add;
