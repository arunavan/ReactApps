import MovieService from './MovieService'
import React,{Component} from 'react'
class GetMovies extends Component {
    constructor(props) {
        super(props)

        this.state = {
                movies: []
        }
        console.log(this.state.movies.name)
     //   this.addEmployee = this.addEmployee.bind(this);
     //   this.editEmployee = this.editEmployee.bind(this);
      //  this.deleteEmployee = this.deleteEmployee.bind(this);
    }

    /*deleteEmployee(id){
        EmployeeService.deleteEmployee(id).then( res => {
            this.setState({employees: this.state.employees.filter(employee => employee.id !== id)});
        });
    }
    viewEmployee(id){
        this.props.history.push(`/view-employee/${id}`);
    }
    editEmployee(id){
        this.props.history.push(`/add-employee/${id}`);
    }*/

    componentDidMount(){
        MovieService.getMovies().then((res) => {
            this.setState({movies :res.data});
        }
       );
      // console.log(this.state.movie.name)
    }

   

    render() {
        return (
            <div>
                 <h2 className="text-center">Movie List</h2>
              
                 <br></br>
                 <div className = "row">
                        <table className = "table table-striped table-bordered">

                            <thead>
                                <tr>
                                    <th> Movie Name</th>
                                    <th> Movie Rating</th>
                                    <th> Movie Generation</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.movies.map(
                                        movies => 
                                        <tr key = {movies.name}>
                                             <td> { movies.name} </td>   
                                             <td> {movies.rating}</td>
                                             <td> {movies.genre}</td>
                                            
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>

                 </div>

            </div>
        )
    }
}

export default GetMovies