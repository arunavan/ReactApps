import React from 'react'; 
import App from '../App'; 
import { create } from 'react-test-renderer' 
describe('My first snapshot test',()=>{
 test('testing app button', () => {
       let tree = create(<App />) 
       expect(tree.toJSON()).toMatchSnapshot(); 
})
 })

/* one more simple logic to test */
describe("A suite", function() {
  it("contains spec with an expectation", function() {
    expect(true).toBe(true);
  });
});


describe("A suite is just a function", function() {
  var a;
  it("and so is a spec", function() {
    a = true;
    expect(a).toBe(true);
  });
});


describe('true is truthy and false is falsy', () => {
  test('true is truthy', () => {
    expect(true).toBe(true);
  });
   test('false is falsy', () => {
    expect(false).toBe(false);
  });
});


/* test logic to test sum component */

function sum(x, y) {
  return x + y;
}
 
describe('sum', () => {
  test('sums up two values', () => {
    expect(sum(2, 4)).toBe(6);
  });
  test('sums up two values', () => {
    expect(sum(2, 6)).toBe(8);
  });
});


describe("jasmine.any", function() {
  it("matches any value", function() {
    expect({}).toEqual(jasmine.any(Object));
    expect(89).toEqual(jasmine.any(Number));
  });
  xdescribe("when used with a spy", function() {
    it("is useful for comparing arguments", function() {
      var foo = jasmine.createSpy('foo');
      foo(12, function() {
        return true;
      });

      expect(foo).toHaveBeenCalledWith(jasmine.any(Number), jasmine.any(Function));
    });
  });
});

/* custom test logic to render App component */
 /*
import React from 'react'; 
import App from '../App'; 
import { create } from 'react-test-renderer' 
describe('My first snapshot test',()=>{
 test('testing app button', () => {
       let tree = create(<App />) 
       expect(tree.toJSON()).toMatchSnapshot(); 
})
 })
*/

/*
import React from 'react';
//import { render } from '@testing-library/react';
import { render, screen } from '@testing-library/react';
import App from './App';
//test logic for default creat-react-app application



test('renders learn react link', () => {
  const { getByText } = render(<App />);
  const linkElement = getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});

*/
