import React,{Component} from 'react'
// eslint-disable-next-line
const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);
const validateForm = (errors) => {
  let valid = true;
  Object.values(errors).forEach(
    (val) => val.length > 0 && (valid = false)
  );
  return valid;
}
const countErrors = (errors) => {
  let count = 0;
  Object.values(errors).forEach(
    (val) => val.length > 0 && (count = count+1)
  );
  return count;
}
class Register extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOnline: false,
      formValid: false,
      errorCount: null,
      errors: {
        fullName: '',
        email: '',
        password: '',
        category:''
      }
    };
  }
  handleChange = (event) => {
    event.preventDefault();
    const { name, value } = event.target;
    let errors = this.state.errors;
     switch (name) {
      case 'fullName': 
        errors.fullName = 
          value.length < 5
            ? 'Full Name must be 5 characters long!'
            : '';
        break;
      case 'email': 
        errors.email = 
          validEmailRegex.test(value)
            ? ''
            : 'Email is not valid!';
        break;
      case 'password': 
        errors.password = 
          value.length < 8
            ? 'Password must be 8 characters long!'
            : '';
        break;
      default:
        break;
    }
    this.setState({errors, [name]: value});
  }
  handleSubmit = (event) => {
    event.preventDefault();
    this.setState({formValid: validateForm(this.state.errors)});
    this.setState({errorCount: countErrors(this.state.errors)});
  }
  render() {
    const {errors, formValid} = this.state;
    console.log(this.state.fullName +  ' '+ this.state.email  +'  '+this.state.password+' '+this.state.category);
     return (
       <div className='wrapper'>
        <div className='form-wrapper'>
            {this.state.errors.fullName}
            {this.state.errors.password}
            {this.state.errors.email}
          <h2>Create Account</h2>
          <form onSubmit={this.handleSubmit} noValidate>
            <div className='fullName'>
              <label htmlFor="fullName">Full Name</label>
              <input type='text' name='fullName' onChange={this.handleChange} noValidate />
              {errors.fullName.length > 0 && 
                <span className='error'>{errors.fullName}</span>}
            </div>
            <div className='email'>
              <label htmlFor="email">Email</label>
              <input type='email' name='email' onChange={this.handleChange} noValidate />
              {errors.email.length > 0 && 
                <span className='error'>{errors.email}</span>}
            </div>
            <div className='password'>
              <label htmlFor="password">Password</label>
              <input type='password' name='password' onChange={this.handleChange} noValidate />
              {errors.password.length > 0 && 
                <span className='error'>{errors.password}</span>}
            </div>
            <label>
            <label>
          Product Online : Yes
          <input
            name="isOnline"
            type="radio"
            checked={this.state.isOnline}
            onChange={this.handleChange} />
            No
            <input
            name="isOnline"
            type="radio"
            checked={this.state.isOnline}
            onChange={this.handleChange} />
        </label>
          <br></br>
          Product Category:
          <select value={this.state.category} onChange={this.handleChange}>
            <option value="grossory">Grossory</option>
            <option value="mobile">Mobile</option>
            <option value="electronics">Electronics</option>
            <option value="cloths">Cloths</option>
          </select>
        </label>
        <br></br>
        <label>
          Available in store:Bigbazar
          <input
            name="isOnline"
            type="checkbox"
            checked={this.state.isOnline1}
            onChange={this.handleChange} />
            DMart
            <input
            name="isOnline"
            type="checkbox"
            checked={this.state.isOnline2}
            onChange={this.handleChange} />
             Reliance
            <input
            name="isOnline"
            type="checkbox"
            checked={this.state.isOnline3}
            onChange={this.handleChange} />
            Megastore
            <input
            name="isOnline"
            type="checkbox"
            checked={this.state.isOnline4}
            onChange={this.handleChange} />
        </label>

            <div className='submit'>
              <button>Create</button>
            </div>
            {this.state.errorCount !== null ? <p className="form-status">Form is {formValid ? 'valid ?' : 'invalid ?'}</p> : 'Form not submitted'}
          </form>
        </div>
      </div>
    );
  }
}
export default Register;