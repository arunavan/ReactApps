import axios from 'axios';

const Movie_URL = "http://localhost:8088/movie";

class MovieService  {

    getMovies(){
        return axios.get(Movie_URL+'/getAllMovies');
    }

    createMovie(movie){
        console.log("--------"+movie);
     /*   const headers ={
             "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "*",
         //   "Access-Control-Allow-Headers": "'Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token'",
    
        }*/
        const HTTP_OPTIONS = {
            headers: {
              'Content-Type':  'application/json',
              'Access-Control-Allow-Credentials' : 'true',
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, PUT, OPTIONS',
              'Access-Control-Allow-Headers': 'Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With',
            }
          };
        return axios.post(Movie_URL+'/addMovie/'+ movie,HTTP_OPTIONS);
    }
    
    getMoviesByGenre(genre){
        return axios.get(Movie_URL + '/getAllMovies/' + genre);
    }

    
}

export default new MovieService()