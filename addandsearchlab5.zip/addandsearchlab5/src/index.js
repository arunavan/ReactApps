import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import Add from './Add'
import Search from './Search'
import { Route, Link,  BrowserRouter as Router } from 'react-router-dom'  
import GetMovies from './GetMovies';
const routing = (  
  <Router>  
    <div>  
    <h1>React Router Example</h1> 
    <ul>  
        <li>  
          <Link to="/">Home</Link>  
        </li>  
        <li>  
          <Link to="/getmovies">GetMovies</Link>  
        </li> 
        <li>  
          <Link to="/add">Add Movies </Link>  
        </li>  
        <li>  
          <Link to="/search">Search Movie by Category</Link>  
        </li>  
      </ul>  

     
      <Route path="/" component={App} />  
      <Route path="/getmovies" component={GetMovies} />  
      <Route path="/add" component={Add} />  
      <Route path="/search" component={Search} />  
    </div>  
  </Router>  
)  
ReactDOM.render(routing, document.getElementById('root'));  



// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
