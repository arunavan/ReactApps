
import './App.css';
import Register from './Register'
function App() {
  return (
    <div className="App">
     <Register/>
     </div>
  );
}
export default App;
