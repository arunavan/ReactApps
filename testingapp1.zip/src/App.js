import React, { Component } from 'react'; 
class App extends Component {
 render() {
 return ( <div className="App"> <button>Show</button>
  </div> ); 
} }
 export default App;




/*import React, { Component } from 'react'; 
class App extends Component {
  state= {
    name: "aruna",
    email:"aruna@Gmail.com"
  }
 render() {
 return ( <div className="App"> 
               <h1> Testing using Jasmine Library </h1>
               <h1> Name : {this.state.name}   Email:   {this.state.email}</h1>
           </div>
            ); 
} }
 export default App;
*/
/*
import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;


*/
/*
import React from 'react';
 
const title = 'Hello React';
 
function App() {
  return <div>{title}</div>;
}
 
export default App;

*/