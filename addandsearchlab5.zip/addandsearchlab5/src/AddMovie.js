import MovieService  from './MovieService'
import React,{Component} from 'react'
class AddMovie extends Component{

    constructor(props){
        super(props);
        this.state ={
            name: '',
           rating: '',
            genre: '',
          
        }
        this.saveMovie = this.saveMovie.bind(this);
    }

    saveMovie = (e) => {
        e.preventDefault();
        let movie = {name: this.state.name, rating: this.state.rating, genre: this.state.genre};
        MovieService.createMovie(movie)
            .then(res => {
                this.setState({message : 'User added successfully.'});
               // this.props.history.push('/users');
            });
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    render() {
        return(
            <div>
                <h2 className="text-center">Add Movie</h2>
                <form>
                <div className="form-group">
                    <label>Movie Name:</label>
                    <input type="text" placeholder="name" name="name" className="form-control" value={this.state.name} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Rating :</label>
                    <input type="number" placeholder="rating" name="rating" className="form-control" value={this.state.rating} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Genere:</label>
                    <input placeholder="Genre" name="genre" className="form-control" value={this.state.genre} onChange={this.onChange}/>
                </div>

              

              

              

                <button className="btn btn-success" onClick={this.saveUser}>Save</button>
            </form>
    </div>
        );
    }
}

export default AddMovie;