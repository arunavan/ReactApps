import React,{Component} from 'react'
// eslint-disable-next-line
const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);
const validateForm = (errors) => {
  let valid = true;
  Object.values(errors).forEach(
    (val) => val.length > 0 && (valid = false)
  );
  return valid;
}
const countErrors = (errors) => {
  let count = 0;
  Object.values(errors).forEach(
    (val) => val.length > 0 && (count = count+1)
  );
  return count;
}
class Search extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOnline: false,
    //  formValid: false,
      errorCount: null,
     /* errors: {
        fullName: '',
        email: '',
        password: '',
        category:''
      }*/
    };
    console.log
  }
  handleChange = (event) => {
    event.preventDefault();
    const { name, value } = event.target;
    let errors = this.state.errors;
     switch (name) {
      case 'fullName': 
        errors.fullName = 
          value.length < 5
            ? 'Full Name must be 5 characters long!'
            : '';
        break;
      case 'email': 
        errors.email = 
          validEmailRegex.test(value)
            ? ''
            : 'Email is not valid!';
        break;
      case 'password': 
        errors.password = 
          value.length < 8
            ? 'Password must be 8 characters long!'
            : '';
        break;
      default:
        break;
    }
    this.setState({errors, [name]: value});
  }
  handleSubmit = (event) => {
    event.preventDefault();
    this.setState({formValid: validateForm(this.state.errors)});
    this.setState({errorCount: countErrors(this.state.errors)});
  }
  render() {
    //const {errors, formValid} = this.state;
    console.log(this.state.fullName +  ' '+ this.state.email  +'  '+this.state.password+' '+this.state.category);
     return (
       <div className='wrapper'>
       
          <form onSubmit={this.handleSubmit} noValidate>
           
          Search Movie:
          <select value={this.state.category} onChange={this.handleChange}>
            <option value="drama">Drama</option>
            <option value="fiction">Fiction</option>
            <option value="sattire">Sattire</option>
           
          </select>
     

            <div className='submit'>
              <button>Search for Movie</button>
            </div>
            </form>
        </div>
      
    );
  }
}

export default Search;
