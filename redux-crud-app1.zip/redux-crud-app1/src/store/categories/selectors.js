export function getCategories(state) {
  return Object.values(state.categoreisState.categoreisById);
}
